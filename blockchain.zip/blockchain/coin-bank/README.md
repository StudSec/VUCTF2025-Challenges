The bank doesn’t track the address of the inserted coin. Users can create their own coin and withdraw another.
