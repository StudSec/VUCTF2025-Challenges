Everyone can call `_authorizeUpgrade`, should implement a custom SC with expected function
