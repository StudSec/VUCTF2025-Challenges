#!/bin/bash
docker compose down
# Exit with the status code of the previous command
exit $?