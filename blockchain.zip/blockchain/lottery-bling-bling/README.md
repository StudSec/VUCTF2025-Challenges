You can bruteforce and if you didn't won revert().
