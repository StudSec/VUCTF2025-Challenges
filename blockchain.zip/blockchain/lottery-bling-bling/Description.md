I created secure randomness on the blockchain. Buy your ticket and test your luck!
